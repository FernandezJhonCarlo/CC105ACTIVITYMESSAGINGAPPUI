# Apps From Scratch: Flutter Chat UI

[YouTube: Flutter Chat UI Tutorial | Apps From Scratch](https://youtu.be/h-igXZCCrrc)